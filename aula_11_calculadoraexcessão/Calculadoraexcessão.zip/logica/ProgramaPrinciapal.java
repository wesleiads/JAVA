package logica;
import grafica.FrmCalculadoraSimples;

public class ProgramaPrinciapal {
    public static void main(String[] args){
        FrmCalculadoraSimples frm= new FrmCalculadoraSimples();
        frm.setVisible(true);
    }
    
}
